from django.contrib import admin
from .models import Course
from .models import Pathway

admin.site.register(Course)
admin.site.register(Pathway)


# Register your models here.
